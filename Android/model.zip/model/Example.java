package model;

/**
 * Created with IntelliJ IDEA.
 * User: hejind
 * Date: 3/1/14
 * Time: 10:29 AM
 * To change this template use File | Settings | File Templates.
 */
public class Example {
    String sentence;
    String cn_explanation;
    String sentence_sound;

    public String getCn_explanation() {
        return cn_explanation;
    }

    public void setCn_explanation(String cn_explanation) {
        this.cn_explanation = cn_explanation;
    }

    public String getSentence_sound() {
        return sentence_sound;
    }

    public void setSentence_sound(String sentence_sound) {
        this.sentence_sound = sentence_sound;
    }

    public String getSentence() {
        return sentence;
    }

    public void setSentence(String sentence) {
        this.sentence = sentence;
    }
}
